function validation(){

    var name, surname, user, password, expresion;
    name = document.getElementById("name").value;
    surname = document.getElementById("surname").value;
    user = document.getElementById("user").value;
    password = document.getElementById("password").value;
    expresion = /\w+@\w+\.+[a-z]/;

    if (name === "" || surname === "" || user === ""|| password === ""){
        alert("Todos los campos son obligatorios");
        return false;
    }
    else if (name.length>30){
        alert("El nombre es muy largo");
        return false;
    }
    else if (surname.length>80){
        alert("El apellido es muy largo");
        return false;
    }
    else if (user.length>20){
        alert("El usuario debe tener 20 carácteres como máximo");
        return false;
    }

}