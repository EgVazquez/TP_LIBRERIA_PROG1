9 lines (6 sloc)  105 Bytes

<?php
  session_start();

  session_unset();

  session_destroy();

  ?>
  <script>
    document.cookie="userid=; Secure; SameSite = Lax;";
    window.location.href="index.php";
    console.log("prueba");
  </script>